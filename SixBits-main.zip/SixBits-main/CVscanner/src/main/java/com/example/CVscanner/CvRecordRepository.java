package com.example.CVscanner;

import org.springframework.data.jpa.repository.JpaRepository;

public interface CvRecordRepository extends JpaRepository<CvRecord, Long> {}
