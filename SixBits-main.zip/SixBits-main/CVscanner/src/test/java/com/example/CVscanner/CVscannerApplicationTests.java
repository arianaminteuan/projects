package com.example.CVscanner;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CVscannerApplicationTests {

	@Test
	void contextLoads() {
	}

}
